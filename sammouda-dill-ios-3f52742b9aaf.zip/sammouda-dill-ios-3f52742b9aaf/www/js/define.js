
var pathRacine="http://dillapp.net:9000/";
var path="http://dillapp.net:9000/api/";
var pathLogin="http://dillapp.net:9000/";