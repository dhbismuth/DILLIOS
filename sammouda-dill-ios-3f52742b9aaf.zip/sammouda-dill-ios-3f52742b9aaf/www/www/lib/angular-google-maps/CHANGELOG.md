<a name"2.1.5"></a>
### 2.1.5 (2015-06-18)


<a name"2.1.4"></a>
### 2.1.4 (2015-06-14)


#### Bug Fixes

* **changelog:** on version bump the next version is used as the main header of the changelog ([cef77ecb](https://github.com/angular-ui/angular-google-maps/commit/cef77ecb))
* **marker:**
  * markers now update on model changes ([f46fd49e](https://github.com/angular-ui/angular-google-maps/commit/f46fd49e))
  * markers now update on model changes ([32086ad4](https://github.com/angular-ui/angular-google-maps/commit/32086ad4))


#### Features

* **RichMarker:** Build all post merge of feature RichMarker which marker and the markers directiv ([323e41f6](https://github.com/angular-ui/angular-google-maps/commit/323e41f6))
* **better graphing:** switched to grunt-angular-architecture-graph ([b4f96dba](https://github.com/angular-ui/angular-google-maps/commit/b4f96dba))
* **bump w changelog:** changelog added to all bumps ([e16a86e8](https://github.com/angular-ui/angular-google-maps/commit/e16a86e8))
* **graphviz:**
  * added to bump routines ([69b317fa](https://github.com/angular-ui/angular-google-maps/commit/69b317fa))
  * trying to aid in documentation and help people figure this out ([b6017de0](https://github.com/angular-ui/angular-google-maps/commit/b6017de0))
* **grunt-changelog:** changelog added to our grunt build, sorry I did not know about this sooner. See  ([84227c03](https://github.com/angular-ui/angular-google-maps/commit/84227c03))

